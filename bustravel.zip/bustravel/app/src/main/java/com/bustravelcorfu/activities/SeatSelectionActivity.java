package com.bustravelcorfu.activities;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.bustravelcorfu.R;
import com.bustravelcorfu.adapters.SeatAdapter;

import java.util.ArrayList;

public class SeatSelectionActivity extends AppCompatActivity {
    ArrayList<Integer> number_seat;
    Toolbar mActionBarToolbar;
    String point, destination, tickets, day, month, year, time;
    Button mButtonPreview;
    int num = 0;
    int mCols;
    SeatAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seat_selection_screen);
        mActionBarToolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mActionBarToolbar);
        mActionBarToolbar.setNavigationIcon(R.drawable.ic_arrow_back_24dp);
        setTitle("Επιλογή Θέσεων");
        number_seat = new ArrayList<>();
        mCols = 4;
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(), mCols);
        RecyclerView recyclerView = findViewById(R.id.cidSeatRecyclerView);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setVisibility(View.VISIBLE);
        mAdapter = new SeatAdapter(this, SeatSelectionActivity.this);
        recyclerView.setAdapter(mAdapter);
        recyclerView.setHasFixedSize(true);


        point = getIntent().getStringExtra("point");
        destination = getIntent().getStringExtra("destination");
        tickets = getIntent().getStringExtra("tickets");
        day = getIntent().getStringExtra("day");
        month = getIntent().getStringExtra("month");
        year = getIntent().getStringExtra("year");
        time = getIntent().getStringExtra("time");
        mButtonPreview = (Button) findViewById(R.id.buttonPreview);
    }


    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {

        switch (menuItem.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
        }

        return super.onOptionsItemSelected(menuItem);
    }

    public void onListItemSelect(int position) {
        Resources resources = getResources();
        mAdapter.toggleSelection(position);
        num = Integer.parseInt(String.valueOf(tickets));

        boolean hasCheckedItems = mAdapter.getSelectedCount() > 0;
        if (mAdapter.getSelectedCount() > num) {
            Toast.makeText(this, "Έχετε επιλέξει τις θέσεις σύμφωνα με τον αριθμό των εισητηρίων", Toast.LENGTH_LONG).show();

        } else {
            if (hasCheckedItems) {
                number_seat.add(position + 1);
                mActionBarToolbar.setTitle(String.valueOf(mAdapter.getSelectedCount()) + " selected");
                mActionBarToolbar.setBackgroundColor(resources.getColor(R.color.colorPrimaryDarkGrey));
                mActionBarToolbar.setNavigationIcon(R.drawable.ic_close);

            } else {
                if(position == 0)
                {
                    number_seat.remove(position);
                    number_seat.clear();
                    mAdapter.removeSelection();
                    mActionBarToolbar.setTitle(resources.getString(R.string.app_name));
                    mActionBarToolbar.setBackgroundColor(resources.getColor(R.color.colorPrimary));
                    mActionBarToolbar.setNavigationIcon(R.drawable.ic_arrow_back_24dp);
                }else{
                    number_seat.remove(position - 1);
                    number_seat.clear();
                    mAdapter.removeSelection();
                    mActionBarToolbar.setTitle(resources.getString(R.string.app_name));
                    mActionBarToolbar.setBackgroundColor(resources.getColor(R.color.colorPrimary));
                    mActionBarToolbar.setNavigationIcon(R.drawable.ic_arrow_back_24dp);
                }

            }
        }
        mButtonPreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (number_seat.size() < num || number_seat.size() > num) {
                    Toast.makeText(getApplicationContext(), "Επιλέξτε σωστά τον αριθμό των θέσεων συμφωνα με τον αριθμό των εισητηρίων", Toast.LENGTH_LONG).show();
                } else {
                    final int price = number_seat.size() * 48;
                    Intent intent = new Intent(getApplicationContext(), BookingActivity.class);
                    intent.putExtra("point", String.valueOf(point));
                    intent.putExtra("destination", String.valueOf(destination));
                    intent.putExtra("tickets", String.valueOf(tickets));
                    intent.putExtra("day", String.valueOf(day));
                    intent.putExtra("month", String.valueOf(month));
                    intent.putExtra("year", String.valueOf(year));
                    intent.putExtra("time", String.valueOf(time));
                    intent.putExtra("seats", number_seat);
                    intent.putExtra("price", price);
                    startActivity(intent);
                }
            }
        });
    }

    public int ticket() {
        return num;
    }
}
