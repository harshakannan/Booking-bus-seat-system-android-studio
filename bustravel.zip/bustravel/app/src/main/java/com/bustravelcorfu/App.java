package com.bustravelcorfu;

import android.app.Application;
import android.content.Context;

import com.bustravelcorfu.entities.DaoSession;

public abstract class App extends Application {

    private final static String TAG = Application.class.getSimpleName();
    private static Context mAppContext;
    protected static DaoSession mDaoSession;

    @Override
    public void onCreate(){
        super.onCreate();

        mAppContext = this;
    }
    public abstract Class<?> getMainActivityClass();

    public static DaoSession getDaoSession() {
        return mDaoSession;
    }

    public static Context getContext() {
        return mAppContext;
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    public static Class<?> getStartActivityClass() {
        return ((App)mAppContext).getMainActivityClass();
    }

}

