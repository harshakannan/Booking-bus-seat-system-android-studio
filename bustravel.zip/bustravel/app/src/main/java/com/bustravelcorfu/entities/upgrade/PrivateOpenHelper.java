package com.bustravelcorfu.entities.upgrade;

import android.content.Context;

import com.bustravelcorfu.entities.DaoMaster;

import org.greenrobot.greendao.database.Database;

public class PrivateOpenHelper extends DaoMaster.OpenHelper {

    private static final String TAG = PrivateOpenHelper.class.getSimpleName();

    public PrivateOpenHelper(Context context, String name) {
        super(context, name);
    }

    @Override
    public void onUpgrade(Database db, int oldVersion, int newVersion){

        DaoMaster.createAllTables(db, true);

		/*switch (newVersion){
			case 2:
				new MigrationV1ToV2().applyMigration(db, oldVersion);
				break;
		}*/
    }
}
