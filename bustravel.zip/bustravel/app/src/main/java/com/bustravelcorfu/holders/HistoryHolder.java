package com.bustravelcorfu.holders;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bustravelcorfu.R;

public class HistoryHolder extends RecyclerView.ViewHolder {

    public TextView mPoint_history;
    public TextView mDestination_history;
    public TextView mDate_history;
    public TextView mPrice_history;
    public ImageView mRemove_history;

    public HistoryHolder(View itemView) {
        super(itemView);

        mPoint_history = (TextView) itemView.findViewById(R.id.point_history);
        mDestination_history = (TextView) itemView.findViewById(R.id.destination_history);
        mDate_history = (TextView) itemView.findViewById(R.id.date_history);
        mPrice_history = (TextView) itemView.findViewById(R.id.price_history);
        mRemove_history = (ImageView) itemView.findViewById(R.id.history_item_remove);
    }
}
