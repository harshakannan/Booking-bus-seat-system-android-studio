package com.bustravelcorfu.activities;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;

import com.bustravelcorfu.BusTravelProvider;
import com.bustravelcorfu.R;
import com.bustravelcorfu.adapters.HistoryAdapter;
import com.bustravelcorfu.entities.History_Booking;

import java.util.ArrayList;
import java.util.List;

public class HistoryBookingActivity extends AppCompatActivity {
    Toolbar mActionBarToolbar;
    RecyclerView recyclerView;
    List<History_Booking> mListHistory;
    HistoryAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_booking);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView = (RecyclerView) findViewById(R.id.cidHistoryRecyclerView);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(mAdapter);
        recyclerView.setHasFixedSize(true);
        mActionBarToolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mActionBarToolbar);
        mActionBarToolbar.setNavigationIcon(R.drawable.ic_arrow_back_24dp);
        setTitle("Ιστορικό Κρατήσεων");

        mListHistory = new ArrayList<>();

        String URL = "content://com.bustravelcorfu.provider/" + BusTravelProvider.HISTORY_BOOKING_PATH + "";
        final Uri _history = Uri.parse(URL);
        final Cursor cursor = getContentResolver().query(_history, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                History_Booking historyBooking = new History_Booking();
                historyBooking.setId(cursor.getLong(0));
                historyBooking.setDeparture_point(cursor.getString(1));
                historyBooking.setDestination(cursor.getString(2));
                historyBooking.setNumber_of_tickets(cursor.getString(3));
                historyBooking.setDate(cursor.getString(4));
                historyBooking.setTime_travel(cursor.getString(5));
                historyBooking.setNumber_of_seat(cursor.getString(6));
                historyBooking.setPrice(cursor.getString(7));
                mListHistory.add(historyBooking);
            }
        }
        if (mListHistory.size() > 0) {
            recyclerView.setVisibility(View.VISIBLE);
            mAdapter = new HistoryAdapter(this, mListHistory, HistoryBookingActivity.this);
            recyclerView.setAdapter(mAdapter);
        } else {
            RelativeLayout cidEmptyRecyclerView = (RelativeLayout) findViewById(R.id.cidEmptyRecyclerView);
            cidEmptyRecyclerView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                Intent mainActivity = new Intent(this, MainActivity.class);
                startActivity(mainActivity);
                break;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
