package com.bustravelcorfu.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.bustravelcorfu.BusTravelProvider;
import com.bustravelcorfu.R;
import com.bustravelcorfu.activities.CancelTicketActivity;
import com.bustravelcorfu.activities.PreviewCancelActivity;
import com.bustravelcorfu.entities.CancelTickets;
import com.bustravelcorfu.holders.CancelTicketHolder;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CancelTicketAdapter extends RecyclerView.Adapter<CancelTicketHolder> {
    private List<CancelTickets> mListCancelTickets;
    private Context mContext;
    private CancelTicketActivity mActivity;

    public CancelTicketAdapter(Context context, List<CancelTickets> cancelTicketsList, CancelTicketActivity activity) {
        this.mContext = context;
        this.mListCancelTickets = cancelTicketsList;
        this.mActivity = activity;
    }

    @NonNull
    @Override
    public CancelTicketHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cancel_ticket_list_item, parent, false);
        return new CancelTicketHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final CancelTicketHolder holder, int position) {
        final CancelTickets cancelTickets = mListCancelTickets.get(position);
        final String date = cancelTickets.getCadate();
        Date _date = Calendar.getInstance().getTime();
        DateFormat df = new SimpleDateFormat("d-M-yyyy ", Locale.getDefault());
        final String today = df.format(_date);

        holder.mPoint_history.setText(new StringBuilder()
                .append(cancelTickets.getCapoint())
                .append(" - "));
        holder.mDestination_history.setText(cancelTickets.getCadestination());
        holder.mDate_history.setText(cancelTickets.getCadate());
        holder.mPrice_history.setText(cancelTickets.getCaprice());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, PreviewCancelActivity.class);
                intent.putExtra("point", cancelTickets.getCapoint());
                intent.putExtra("destination", cancelTickets.getCadestination());
                intent.putExtra("tickets", cancelTickets.getCatickets());
                intent.putExtra("date", cancelTickets.getCadate());
                intent.putExtra("time", cancelTickets.getCatimetravel());
                intent.putExtra("seats", cancelTickets.getCanumberofseat());
                intent.putExtra("price", cancelTickets.getCaprice());
                mContext.startActivity(intent);
            }
        });

        holder.mCancel_Ticket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(date.equals(today)){
                    Toast.makeText(mContext, "Δεν μπορείτε να ακυρώσετε το εισιτήριο σας, λόγω ημερομηνίας", Toast.LENGTH_LONG).show();
                }else {
                    dialogCancelTicket(holder, holder.getAdapterPosition());
                }

            }
        });

        holder.mRemoveItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogRemoveCancelTicket(holder, holder.getAdapterPosition());
            }
        });
    }

    private void dialogCancelTicket(final CancelTicketHolder holder, final int position) {
        final CancelTickets cancelTickets = mListCancelTickets.get(position);
        final long id = cancelTickets.getId();
        LayoutInflater layoutInflater = LayoutInflater.from(mActivity);
        View dialogView = layoutInflater.inflate(R.layout.dialog_cancel_ticket, null);
        final AlertDialog dialog = new AlertDialog.Builder(mActivity).create();
        Button btnNo = dialogView.findViewById(R.id.btn_no);
        Button btnYes = dialogView.findViewById(R.id.btn_yes);
        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.getContentResolver().delete(BusTravelProvider.CONTENT_CANCEL_TICKET_DELETE, String.valueOf(id), null);
                mListCancelTickets.remove(holder.getAdapterPosition());
                notifyItemRemoved(holder.getAdapterPosition());
                Toast.makeText(mContext, "Το εισιτήριό σας ακυρώθηκε. Η επιστροφή των χρημάτων σας θα πραγματοποιηθεί εντός 3 εργάσιμων ημερών.", Toast.LENGTH_LONG).show();
                new android.os.Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        dialog.dismiss();
                    }
                });
            }
        });

        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.setView(dialogView);
        dialog.show();
    }

    private void dialogRemoveCancelTicket(final CancelTicketHolder holder, final int position) {
        final CancelTickets cancelTickets = mListCancelTickets.get(position);
        final long id = cancelTickets.getId();
        LayoutInflater layoutInflater = LayoutInflater.from(mActivity);
        View dialogView = layoutInflater.inflate(R.layout.dialog_confirm_delete, null);
        final AlertDialog dialog = new AlertDialog.Builder(mActivity).create();
        Button btnNo = dialogView.findViewById(R.id.btn_no);
        Button btnYes = dialogView.findViewById(R.id.btn_yes);
        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.getContentResolver().delete(BusTravelProvider.CONTENT_CANCEL_TICKET_DELETE, String.valueOf(id), null);
                mListCancelTickets.remove(holder.getAdapterPosition());
                notifyItemRemoved(holder.getAdapterPosition());
                Toast.makeText(mContext, "Επιτυχής διαγραφή", Toast.LENGTH_LONG).show();
                new android.os.Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        dialog.dismiss();
                    }
                });
            }
        });

        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.setView(dialogView);
        dialog.show();
    }

    @Override
    public int getItemCount() {
        return mListCancelTickets.size();
    }
}
