package com.bustravelcorfu.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bustravelcorfu.R;

import java.util.Objects;

public class AboutActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        setTitle("Πληροφορίες");

        ImageView mEmail = findViewById(R.id.send_email);
        ImageView mRate = findViewById(R.id.rate);
        TextView mVersion = findViewById(R.id.version);

        String version = "";
        PackageManager pm = this.getPackageManager();
        try {
            PackageInfo pi = pm.getPackageInfo(this.getPackageName(), PackageManager.GET_META_DATA);
            version = pi.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String appName = getResources().getString(R.string.app_name) + " " + version;
        mVersion.setText(appName);
    }

    public void rateApplication (View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW)
                .setData(Uri
                        .parse("https://play.google.com/store"));/*replace url from app in play store */
        startActivity(intent);
    }

    public void sendFeedbackmail (View view){
        Intent Email = new Intent(Intent.ACTION_SEND);
        Email.setType("text/email");
        Email.putExtra(Intent.EXTRA_EMAIL, new String[]{"infotravelbus08@gmail.com"});
        Email.putExtra(Intent.EXTRA_SUBJECT, "Feedback from " + Build.MODEL + " user");
        Email.putExtra(Intent.EXTRA_TEXT, "Hallo," + "");
        startActivity(Intent.createChooser(Email, "Send Feedback:"));
    }

    @SuppressLint("RestrictedApi")
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {

        switch (menuItem.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
        }

        return super.onOptionsItemSelected(menuItem);
    }
}
