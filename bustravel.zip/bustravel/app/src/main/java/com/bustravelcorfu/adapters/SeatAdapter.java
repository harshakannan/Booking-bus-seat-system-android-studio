package com.bustravelcorfu.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bustravelcorfu.R;
import com.bustravelcorfu.activities.SeatSelectionActivity;
import com.bustravelcorfu.holders.SeatHolder;

public class SeatAdapter extends RecyclerView.Adapter<SeatHolder> {
    private Context mContext;
    private SparseBooleanArray mSelectedSeats;
    private SeatSelectionActivity mActivity;

    public SeatAdapter(Context context, SeatSelectionActivity activity) {
        this.mContext = context;
        this.mActivity = activity;
        mSelectedSeats = new SparseBooleanArray();

    }

    @NonNull
    @Override
    public SeatHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.activity_grid_seat_item, parent, false);
        return new SeatHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final SeatHolder holder, final int position) {
        int seat_free = mContext.getResources().getIdentifier("com.bustravelcorfu:drawable/seat_free", null, null);
        int seat_select = mContext.getResources().getIdentifier("com.bustravelcorfu:drawable/seat_select", null, null);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mActivity.onListItemSelect(holder.getAdapterPosition());

            }
        });

        if (mSelectedSeats.get(position)) {
            holder.mSeatText.setText(new StringBuilder().append("Select"));
            holder.mSeatImage.setImageResource(seat_select);

        } else {
            holder.mSeatText.setText(new StringBuilder().append("Seat ").append(String.valueOf(position + 1)));
            holder.mSeatImage.setImageResource(seat_free);
        }
    }

    @Override
    public int getItemCount() {
        return 50;
    }

    private void selectView(int position, boolean sel) {
        if (sel) {
            mSelectedSeats.put(position, sel);
        } else {
            mSelectedSeats.delete(position);
        }
        notifyDataSetChanged();
    }

    public void toggleSelection(int position) {
        selectView(position, !mSelectedSeats.get(position));
    }

    public int getSelectedCount() {
        return mSelectedSeats.size();
    }

    private SparseBooleanArray getmSelectedIds() {
        return mSelectedSeats;
    }

    public void removeSelection() {
        mSelectedSeats = new SparseBooleanArray();
        notifyDataSetChanged();
    }
}
