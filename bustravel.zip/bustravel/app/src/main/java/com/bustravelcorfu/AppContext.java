package com.bustravelcorfu;

import com.bustravelcorfu.activities.LoginActivity;
import com.bustravelcorfu.entities.DaoMaster;
import com.bustravelcorfu.entities.upgrade.PrivateOpenHelper;

import org.greenrobot.greendao.database.Database;

public class AppContext extends App {

    @Override
    public void onCreate() {
        super.onCreate();
        PrivateOpenHelper helper = new PrivateOpenHelper(this, "bustravelcorfu");
        Database db = helper.getEncryptedWritableDb("The true sign of intelligence is not knowledge but imagination");
        mDaoSession = new DaoMaster(db).newSession();
    }
    @Override
    public Class<?> getMainActivityClass() {
        return LoginActivity.class;
    }
}
