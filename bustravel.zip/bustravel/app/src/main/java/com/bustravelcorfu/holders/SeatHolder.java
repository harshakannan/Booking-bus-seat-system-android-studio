package com.bustravelcorfu.holders;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bustravelcorfu.R;

public class SeatHolder extends RecyclerView.ViewHolder {
    public TextView mSeatText;
    public ImageView mSeatImage;
    public SeatHolder(View itemView) {
        super(itemView);
        mSeatText = itemView.findViewById(R.id.seat_text);
        mSeatImage = itemView.findViewById(R.id.seat_image);
    }
}
