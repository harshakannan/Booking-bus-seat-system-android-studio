package com.bustravelcorfu.entities;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;

@Entity
public class Users {
    @Id
    private Long id;
    private String username;
    private String password;
    private String pinuser;
    @Generated(hash = 2021454661)
    public Users(Long id, String username, String password, String pinuser) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.pinuser = pinuser;
    }
    @Generated(hash = 2146996206)
    public Users() {
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getUsername() {
        return this.username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return this.password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getPinuser() {
        return this.pinuser;
    }
    public void setPinuser(String pinuser) {
        this.pinuser = pinuser;
    }
}
