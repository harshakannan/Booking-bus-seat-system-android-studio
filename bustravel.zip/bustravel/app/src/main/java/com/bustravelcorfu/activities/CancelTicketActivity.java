package com.bustravelcorfu.activities;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;

import com.bustravelcorfu.BusTravelProvider;
import com.bustravelcorfu.R;
import com.bustravelcorfu.adapters.CancelTicketAdapter;
import com.bustravelcorfu.entities.CancelTickets;

import java.util.ArrayList;
import java.util.List;

public class CancelTicketActivity extends AppCompatActivity {
    Toolbar mActionBarToolbar;
    RecyclerView recyclerView;
    List<CancelTickets> mListCancelTickets;
    CancelTicketAdapter mAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel_ticket); LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView = (RecyclerView) findViewById(R.id.cidCancelRecyclerView);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(mAdapter);
        recyclerView.setHasFixedSize(true);
        mActionBarToolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mActionBarToolbar);
        mActionBarToolbar.setNavigationIcon(R.drawable.ic_arrow_back_24dp);
        setTitle("Ακύρωση Εισιτηρίων");

        mListCancelTickets = new ArrayList<>();

        String URL = "content://com.bustravelcorfu.provider/" + BusTravelProvider.CANCEL_TICKET_PATH + "";
        final Uri _cancel = Uri.parse(URL);
        final Cursor cursor = getContentResolver().query(_cancel, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                CancelTickets cancelTickets = new CancelTickets();
                cancelTickets.setId(cursor.getLong(0));
                cancelTickets.setCapoint(cursor.getString(1));
                cancelTickets.setCadestination(cursor.getString(2));
                cancelTickets.setCatickets(cursor.getString(3));
                cancelTickets.setCadate(cursor.getString(4));
                cancelTickets.setCatimetravel(cursor.getString(5));
                cancelTickets.setCanumberofseat(cursor.getString(6));
                cancelTickets.setCaprice(cursor.getString(7));
                mListCancelTickets.add(cancelTickets);
            }
        }
        if (mListCancelTickets.size() > 0) {
            recyclerView.setVisibility(View.VISIBLE);
            mAdapter = new CancelTicketAdapter(this, mListCancelTickets, CancelTicketActivity.this);
            recyclerView.setAdapter(mAdapter);
        } else {
            RelativeLayout cidEmptyRecyclerView = (RelativeLayout) findViewById(R.id.cidEmptyRecyclerView);
            cidEmptyRecyclerView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                Intent mainActivity = new Intent(this, MainActivity.class);
                startActivity(mainActivity);
                break;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
