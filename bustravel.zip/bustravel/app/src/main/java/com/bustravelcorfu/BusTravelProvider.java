package com.bustravelcorfu;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.bustravelcorfu.database.SqliteDatabase;
import com.bustravelcorfu.entities.CancelTicketsDao;
import com.bustravelcorfu.entities.History_BookingDao;
import com.bustravelcorfu.entities.UsersDao;

public class BusTravelProvider extends ContentProvider {
    SqliteDatabase dbHelper;
    private SQLiteDatabase db;
    //Authority
    public static final String AUTHORITY = "com.bustravelcorfu.provider";

    //Paths
    public static final String USERS_PATH = UsersDao.TABLENAME;
    public static final String HISTORY_BOOKING_PATH = History_BookingDao.TABLENAME;
    public static final String CANCEL_TICKET_PATH = CancelTicketsDao.TABLENAME;

    public static final String INSERT_PATH = "insert";
    public static final String DELETE_PATH = "delete";
    public static final String UPDATE_PATH = "update";

    //Users uri
    public static final Uri CONTENT_USERS_URI = Uri.parse("content://" + AUTHORITY + "/" + USERS_PATH);
    public static final Uri CONTENT_USERS_URI_INSERT = Uri.parse("content://" + AUTHORITY + "/" + USERS_PATH + "/" + INSERT_PATH);
    public static final Uri CONTENT_USERS_URI_UPDATE = Uri.parse("content://" + AUTHORITY + "/" + USERS_PATH + "/" + UPDATE_PATH);

    //History Booking uri
    public static final Uri CONTENT_HISTORY_BOOK_URI = Uri.parse("content://" + AUTHORITY + "/" + HISTORY_BOOKING_PATH);
    public static final Uri CONTENT_HISTORY_BOOK_INSERT = Uri.parse("content://" + AUTHORITY + "/" + HISTORY_BOOKING_PATH + "/" + INSERT_PATH);
    public static final Uri CONTENT_HISTORY_BOOK_DELETE = Uri.parse("content://" + AUTHORITY + "/" + HISTORY_BOOKING_PATH + "/" + DELETE_PATH);

    //Cancel Tickets Uri
    public static final Uri CONTENT_CANCEL_TICKETS_URI = Uri.parse("content://" + AUTHORITY + "/" + CANCEL_TICKET_PATH);
    public static final Uri CONTENT_CANCEL_TICKET_INSERT = Uri.parse("content://" + AUTHORITY + "/" + CANCEL_TICKET_PATH + "/" + INSERT_PATH);
    public static final Uri CONTENT_CANCEL_TICKET_DELETE = Uri.parse("content://" + AUTHORITY + "/" + CANCEL_TICKET_PATH + "/" + DELETE_PATH);
    public static final Uri CONTENT_CANCEL_TICKET_UPDATE = Uri.parse("content://" + AUTHORITY + "/" + CANCEL_TICKET_PATH + "/" + UPDATE_PATH);

    //Users Columns
    public static final String COLUMN_USER_ID = UsersDao.Properties.Id.columnName;
    public static final String COLUMN_USERNAME = UsersDao.Properties.Username.columnName;
    public static final String COLUMN_USER_PASSWORD = UsersDao.Properties.Password.columnName;
    public static final String COLUMN_PIN_USER = UsersDao.Properties.Pinuser.columnName;

    //History Booking Columns
    public static final String COLUMN_HISTORY_BOOK_ID = History_BookingDao.Properties.Id.columnName;
    public static final String COLUMN_DEPARTURE_POINT = History_BookingDao.Properties.Departure_point.columnName;
    public static final String COLUMN_DESTINATION = History_BookingDao.Properties.Destination.columnName;
    public static final String COLUMN_NUMBER_OF_TICKETS = History_BookingDao.Properties.Number_of_tickets.columnName;
    public static final String COLUMN_DATE = History_BookingDao.Properties.Date.columnName;
    public static final String COLUMN_TIME_TRAVEL = History_BookingDao.Properties.Time_travel.columnName;
    public static final String COLUMN_NUMBER_OF_SEAT = History_BookingDao.Properties.Number_of_seat.columnName;
    public static final String COLUMN_PRICE = History_BookingDao.Properties.Price.columnName;

    //Cancel Tickets Columns
    public static final String COLUMN_CANCEL_TICKET_ID = CancelTicketsDao.Properties.Id.columnName;
    public static final String COLUMN_CA_DEPARTURE_POINT = CancelTicketsDao.Properties.Capoint.columnName;
    public static final String COLUMN_CA_DESTINATION = CancelTicketsDao.Properties.Cadestination.columnName;
    public static final String COLUMN_CA_TICKETS = CancelTicketsDao.Properties.Catickets.columnName;
    public static final String COLUMN_CA_DATE = CancelTicketsDao.Properties.Cadate.columnName;
    public static final String COLUMN_CA_TIME_TRAVEL = CancelTicketsDao.Properties.Catimetravel.columnName;
    public static final String COLUMN_CA_NUMBER_SEAT = CancelTicketsDao.Properties.Canumberofseat.columnName;
    public static final String COLUMN_CA_PRICE = CancelTicketsDao.Properties.Caprice.columnName;

    public static final int USERS_ID = 1;
    public static final int USERS = 2;
    public static final int USERS_ID_DELETE = 3;
    public static final int USERS_INSERT = 4;
    public static final int USERS_UPDATE = 5;

    public static final int HISTORY_BOOK_ID = 6;
    public static final int HISTORY_BOOKING = 7;
    public static final int HISTORY_BOOK_ID_DELETE = 8;
    public static final int HISTORY_BOOK_INSERT = 9;

    public static final int CANCEL_TICKET_ID = 10;
    public static final int CANCEL_TICKET = 11;
    public static final int CANCEL_TICKET_ID_DELETE = 12;
    public static final int CANCEL_TICKET_INSERT = 13;
    public static final int CANCEL_TICKET_UPDATE = 14;

    static final UriMatcher uriMatcher;
    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

        //Users UriMatcher
        uriMatcher.addURI(AUTHORITY, USERS_PATH, USERS);
        uriMatcher.addURI(AUTHORITY, USERS_PATH + "/#", USERS_ID);
        uriMatcher.addURI(AUTHORITY, USERS_PATH + "/" + INSERT_PATH, USERS_INSERT);
        uriMatcher.addURI(AUTHORITY, USERS_PATH + "/" + DELETE_PATH, USERS_ID_DELETE);
        uriMatcher.addURI(AUTHORITY, USERS_PATH + "/" + UPDATE_PATH, USERS_UPDATE);

        //History Booking UriMatcher
        uriMatcher.addURI(AUTHORITY, HISTORY_BOOKING_PATH, HISTORY_BOOKING);
        uriMatcher.addURI(AUTHORITY, HISTORY_BOOKING_PATH + "/#", HISTORY_BOOK_ID);
        uriMatcher.addURI(AUTHORITY, HISTORY_BOOKING_PATH + "/" + INSERT_PATH, HISTORY_BOOK_INSERT);
        uriMatcher.addURI(AUTHORITY, HISTORY_BOOKING_PATH + "/" + DELETE_PATH, HISTORY_BOOK_ID_DELETE);

        //Cancel Tickets UriMatcher
        uriMatcher.addURI(AUTHORITY, CANCEL_TICKET_PATH, CANCEL_TICKET);
        uriMatcher.addURI(AUTHORITY, CANCEL_TICKET_PATH + "/#", CANCEL_TICKET_ID);
        uriMatcher.addURI(AUTHORITY, CANCEL_TICKET_PATH + "/" + INSERT_PATH, CANCEL_TICKET_INSERT);
        uriMatcher.addURI(AUTHORITY, CANCEL_TICKET_PATH + "/" + DELETE_PATH, CANCEL_TICKET_ID_DELETE);
        uriMatcher.addURI(AUTHORITY, CANCEL_TICKET_PATH + "/" + UPDATE_PATH, CANCEL_TICKET_UPDATE);
    }

    public static Uri CONTENT_URI_USERS_GET(long id) {
        return CONTENT_USERS_URI
                .buildUpon()
                .appendEncodedPath(String.valueOf(id))
                .build();
    }

    public static Uri CONTENT_URI_HISTORY_BOOK_GET (long id){
        return CONTENT_HISTORY_BOOK_URI
                .buildUpon()
                .appendEncodedPath(String.valueOf(id))
                .build();
    }

    public static  Uri CONTENT_URI_CANCEL_TICKETS_GET (long id){
        return CONTENT_CANCEL_TICKETS_URI
                .buildUpon()
                .appendEncodedPath(String.valueOf(id))
                .build();
    }

    @Override
    public boolean onCreate() {
        Context context = getContext();
        dbHelper = new SqliteDatabase(context);
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        // Use SQLiteQueryBuilder for querying db
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        //Record id
        String userId;
        String bookId;
        String cancelId;
        switch (uriMatcher.match(uri)) {
            case USERS:
                qb.setTables(UsersDao.TABLENAME);
                break;
            case USERS_ID:
                qb.appendWhere(UsersDao.Properties.Id.columnName + "= ?");
                userId = uri.getLastPathSegment();
                selectionArgs = new String[]{userId};
                break;
            case HISTORY_BOOKING:
                qb.setTables(History_BookingDao.TABLENAME);
                break;
            case HISTORY_BOOK_ID:
                qb.appendWhere(History_BookingDao.Properties.Id.columnName + "= ?");
                bookId = uri.getLastPathSegment();
                selectionArgs = new String[]{bookId};
                break;
            case CANCEL_TICKET:
                qb.setTables(CancelTicketsDao.TABLENAME);
                break;
            case CANCEL_TICKET_ID:
                qb.appendWhere(CancelTicketsDao.Properties.Id.columnName + "= ?");
                cancelId = uri.getLastPathSegment();
                selectionArgs = new String[]{cancelId};
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }
        String tables = uri.getQueryParameter("tables");
        if (!TextUtils.isEmpty(tables))
            qb.setTables(tables);

        db = dbHelper.getReadableDatabase();
        Cursor cursor = qb.query(
                db,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );
        if (getContext() != null)
            cursor.setNotificationUri(getContext().getContentResolver(), uri);

        return cursor;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        db = dbHelper.getWritableDatabase();
        int uriType = uriMatcher.match(uri);
        Uri res;
        long rowId;

        switch (uriType) {
            case USERS_INSERT:
                rowId = db.insertOrThrow(USERS_PATH, null, values);
                res = CONTENT_URI_USERS_GET(rowId);
                break;
            case HISTORY_BOOK_INSERT:
                rowId = db.insertOrThrow(HISTORY_BOOKING_PATH, null, values);
                res = CONTENT_URI_HISTORY_BOOK_GET(rowId);
                break;
            case CANCEL_TICKET_INSERT:
                rowId = db.insertOrThrow(CANCEL_TICKET_PATH, null, values);
                res = CONTENT_URI_CANCEL_TICKETS_GET(rowId);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }
        if (getContext() != null)
            getContext().getContentResolver().notifyChange(uri, null);

        return res;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        int count = 0;

        switch (uriMatcher.match(uri)) {
            case USERS:
                db.delete(UsersDao.TABLENAME, selection, selectionArgs);
                break;
            case USERS_ID_DELETE:
                db.execSQL("DELETE FROM " + UsersDao.TABLENAME + " WHERE " + UsersDao.Properties.Id.columnName + " = '" + selection + "'");
                break;
            case HISTORY_BOOKING:
                db.delete(History_BookingDao.TABLENAME, selection, selectionArgs);
                break;
            case HISTORY_BOOK_ID_DELETE:
                db.execSQL("DELETE FROM " + History_BookingDao.TABLENAME + " WHERE " + History_BookingDao.Properties.Id.columnName + " = '" + selection + "'");
                break;
            case CANCEL_TICKET:
                db.delete(CancelTicketsDao.TABLENAME, selection, selectionArgs);
                break;
            case CANCEL_TICKET_ID_DELETE:
                db.execSQL("DELETE FROM " + CancelTicketsDao.TABLENAME + " WHERE " + CancelTicketsDao.Properties.Id.columnName + " = '" + selection + "'");
                break;
            default:
                throw new IllegalArgumentException("UnknownURI" + uri);
        }
        if (getContext() != null)
            getContext().getContentResolver().notifyChange(uri, null);

        return count;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        int count = 0;

        switch (uriMatcher.match(uri)) {
            case USERS_UPDATE:
                count = db.update(UsersDao.TABLENAME, values, selection, selectionArgs);
                break;
            case USERS_ID:
                count = db.update(UsersDao.TABLENAME, values, COLUMN_USER_ID + " = " + selection, selectionArgs);
                break;
            case CANCEL_TICKET_UPDATE:
                count = db.update(CancelTicketsDao.TABLENAME, values, selection, selectionArgs);
                break;
            case CANCEL_TICKET_ID:
                count = db.update(CancelTicketsDao.TABLENAME, values, COLUMN_CANCEL_TICKET_ID + " = " + selection, selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI" + uri);
        }
        if (getContext() != null)
            getContext().getContentResolver().notifyChange(uri, null);
        return count;
    }
}
