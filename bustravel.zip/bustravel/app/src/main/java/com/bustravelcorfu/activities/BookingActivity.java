package com.bustravelcorfu.activities;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.bustravelcorfu.BusTravelProvider;
import com.bustravelcorfu.R;
import com.paypal.android.sdk.payments.PayPalConfiguration;
import com.paypal.android.sdk.payments.PayPalPayment;
import com.paypal.android.sdk.payments.PayPalService;
import com.paypal.android.sdk.payments.PaymentActivity;
import com.paypal.android.sdk.payments.PaymentConfirmation;

import org.json.JSONException;

import java.math.BigDecimal;
import java.util.ArrayList;

public class BookingActivity extends AppCompatActivity {
    TextView mPoint_preview, mDestination_preview, mTickets_preview, mDate_preview, mSeatPreview, mTimePreview, mPricePreview;
    String point, destination, tickets, day, month, year, time;
    ArrayList<Integer> number_seat;
    int price;
    Toolbar mActionBarToolbar;
    private static final String CONFIG_CLIENT_ID = "Ad0ykJvGQoeMonKmfFlepZRQzU5LVu_JQqK8CBrpGpAj39jeB9WrFNLP0Kc3RcEAyR4w34iVAcyvOPQv";
    private static PayPalConfiguration config = new PayPalConfiguration()
            .environment(PayPalConfiguration.ENVIRONMENT_SANDBOX)
            .clientId(CONFIG_CLIENT_ID);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);
        mActionBarToolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mActionBarToolbar);
        mActionBarToolbar.setNavigationIcon(R.drawable.ic_arrow_back_24dp);
        setTitle("Κράτηση Θέσεων");

        point = getIntent().getStringExtra("point");
        destination = getIntent().getStringExtra("destination");
        tickets = getIntent().getStringExtra("tickets");
        day = getIntent().getStringExtra("day");
        month = getIntent().getStringExtra("month");
        year = getIntent().getStringExtra("year");
        time = getIntent().getStringExtra("time");
        price = getIntent().getIntExtra("price", 0);
        number_seat = getIntent().getIntegerArrayListExtra("seats");
        final Button button = (Button) findViewById(R.id.paypal_button);

        mPoint_preview = (TextView) findViewById(R.id.point_preview_dialog);
        mDestination_preview = (TextView) findViewById(R.id.destination_preview_dialog);
        mTickets_preview = (TextView) findViewById(R.id.tickets_preview_dialog);
        mDate_preview = (TextView) findViewById(R.id.date_preview_dialog);
        mSeatPreview = (TextView) findViewById(R.id.seat_preview_dialog);
        mTimePreview = (TextView) findViewById(R.id.time_preview_dialog);
        mPricePreview = (TextView) findViewById(R.id.price_preview_dialog);

        final StringBuilder builder = new StringBuilder();

        mPoint_preview.setText(point);
        mDestination_preview.setText(destination);
        mTickets_preview.setText(tickets);
        mTimePreview.setText(time);
        mDate_preview.setText(new StringBuilder()
                .append(day).append("-")
                .append(month).append("-")
                .append(year).append(" "));
        for (int i = 0; i < number_seat.size(); i++) {
            builder.append(String.valueOf(number_seat.get(i) + "k "));
        }
        mSeatPreview.setText(builder.toString());
        mPricePreview.setText(new StringBuilder()
                .append(String.valueOf(price)).append(" ")
                .append("€"));

    }

    public void beginPayment(View view) {
        Intent serviceConfig = new Intent(this, PayPalService.class);
        serviceConfig.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION, config);
        startService(serviceConfig);

        PayPalPayment payment = new PayPalPayment(new BigDecimal(price),
                "EUR", "Τιμή εισητηρίων", PayPalPayment.PAYMENT_INTENT_SALE);

        Intent paymentConfig = new Intent(this, PaymentActivity.class);
        paymentConfig.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION, config);
        paymentConfig.putExtra(PaymentActivity.EXTRA_PAYMENT, payment);
        startActivityForResult(paymentConfig, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            PaymentConfirmation confirm = data.getParcelableExtra(
                    PaymentActivity.EXTRA_RESULT_CONFIRMATION);
            if (confirm != null) {
                try {
                    Log.i("bustravel", confirm.toJSONObject().toString(4));
                    String _point = mPoint_preview.getText().toString();
                    String _destination = mDestination_preview.getText().toString();
                    String _tickets = mTickets_preview.getText().toString();
                    String _date = mDate_preview.getText().toString();
                    String _time = mTimePreview.getText().toString();
                    String _seats = mSeatPreview.getText().toString();
                    String _price = mPricePreview.getText().toString();
                    ContentValues values = new ContentValues();
                    values.put(BusTravelProvider.COLUMN_CA_DEPARTURE_POINT, _point);
                    values.put(BusTravelProvider.COLUMN_CA_DESTINATION, _destination);
                    values.put(BusTravelProvider.COLUMN_CA_TICKETS, _tickets);
                    values.put(BusTravelProvider.COLUMN_CA_DATE, _date);
                    values.put(BusTravelProvider.COLUMN_CA_TIME_TRAVEL, _time);
                    values.put(BusTravelProvider.COLUMN_CA_NUMBER_SEAT, _seats);
                    values.put(BusTravelProvider.COLUMN_CA_PRICE, _price);

                    getContentResolver().insert(BusTravelProvider.CONTENT_CANCEL_TICKET_INSERT, values);
                    Toast.makeText(this, "Η αγορά έγινε με επιτυχία", Toast.LENGTH_LONG).show();
                    dialogSaveOnHistory();
                    // TODO: send 'confirm' to your server for verification

                } catch (JSONException e) {
                    Log.e("bustravel", "no confirmation data: ", e);
                }
            }
        } else if (resultCode == Activity.RESULT_CANCELED) {
            Log.i("bustravel", "The user canceled.");
        } else if (resultCode == PaymentActivity.RESULT_EXTRAS_INVALID) {
            Log.i("bustravel", "Invalid payment / config set");
        }
    }

    private void dialogExit() {
        LayoutInflater layoutInflater = LayoutInflater.from(this);
        View dialogExitView = layoutInflater.inflate(R.layout.dialog_exit_booking, null);
        final AlertDialog dialogExit = new AlertDialog.Builder(this).create();
        Button btnNo = dialogExitView.findViewById(R.id.btn_no);
        Button btnYes = dialogExitView.findViewById(R.id.btn_yes);

        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogExit.dismiss();
            }
        });

        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        dialogExit.dismiss();
                    }
                });
            }
        });
        dialogExit.setView(dialogExitView);
        dialogExit.show();

    }

    @Override
    public void onDestroy() {
        // Stop service when done
        stopService(new Intent(this, PayPalService.class));
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        dialogExit();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {

        switch (menuItem.getItemId()) {
            case android.R.id.home:
                dialogExit();
                break;
        }

        return super.onOptionsItemSelected(menuItem);
    }

    private void dialogSaveOnHistory() {
        LayoutInflater layoutInflater = LayoutInflater.from(this);
        View dialogView = layoutInflater.inflate(R.layout.dialog_confirm_save_history, null);
        final android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this).create();
        Button btnNo = dialogView.findViewById(R.id.btn_no);
        Button btnYes = dialogView.findViewById(R.id.btn_yes);

        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String _point = mPoint_preview.getText().toString();
                String _destination = mDestination_preview.getText().toString();
                String _tickets = mTickets_preview.getText().toString();
                String _date = mDate_preview.getText().toString();
                String _time = mTimePreview.getText().toString();
                String _seats = mSeatPreview.getText().toString();
                String _price = mPricePreview.getText().toString();
                ContentValues values = new ContentValues();
                values.put(BusTravelProvider.COLUMN_DEPARTURE_POINT, _point);
                values.put(BusTravelProvider.COLUMN_DESTINATION, _destination);
                values.put(BusTravelProvider.COLUMN_NUMBER_OF_TICKETS, _tickets);
                values.put(BusTravelProvider.COLUMN_DATE, _date);
                values.put(BusTravelProvider.COLUMN_TIME_TRAVEL, _time);
                values.put(BusTravelProvider.COLUMN_NUMBER_OF_SEAT, _seats);
                values.put(BusTravelProvider.COLUMN_PRICE, _price);

                getContentResolver().insert(BusTravelProvider.CONTENT_HISTORY_BOOK_INSERT, values);
                Toast.makeText(getApplicationContext(), "Αποθηκεύτηκε", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(BookingActivity.this, MainActivity.class);
                startActivity(intent);
                new android.os.Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        dialog.dismiss();
                    }
                });
            }
        });

        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Intent intent = new Intent(BookingActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        dialog.setView(dialogView);
        dialog.show();
    }
}
