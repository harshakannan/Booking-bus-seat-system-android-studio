package com.bustravelcorfu.entities;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;

import org.greenrobot.greendao.annotation.Generated;

@Entity
public class History_Booking {

    @Id

    private Long id;
    private String departure_point;
    private String destination;
    private String number_of_tickets;
    private String date;
    private String time_travel;
    private String number_of_seat;
    private String price;
    @Generated(hash = 817411440)
    public History_Booking(Long id, String departure_point, String destination,
            String number_of_tickets, String date, String time_travel,
            String number_of_seat, String price) {
        this.id = id;
        this.departure_point = departure_point;
        this.destination = destination;
        this.number_of_tickets = number_of_tickets;
        this.date = date;
        this.time_travel = time_travel;
        this.number_of_seat = number_of_seat;
        this.price = price;
    }
    @Generated(hash = 2018072700)
    public History_Booking() {
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getDeparture_point() {
        return this.departure_point;
    }
    public void setDeparture_point(String departure_point) {
        this.departure_point = departure_point;
    }
    public String getDestination() {
        return this.destination;
    }
    public void setDestination(String destination) {
        this.destination = destination;
    }
    public String getNumber_of_tickets() {
        return this.number_of_tickets;
    }
    public void setNumber_of_tickets(String number_of_tickets) {
        this.number_of_tickets = number_of_tickets;
    }
    public String getDate() {
        return this.date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getTime_travel() {
        return this.time_travel;
    }
    public void setTime_travel(String time_travel) {
        this.time_travel = time_travel;
    }
    public String getNumber_of_seat() {
        return this.number_of_seat;
    }
    public void setNumber_of_seat(String number_of_seat) {
        this.number_of_seat = number_of_seat;
    }
    public String getPrice() {
        return this.price;
    }
    public void setPrice(String price) {
        this.price = price;
    }
}