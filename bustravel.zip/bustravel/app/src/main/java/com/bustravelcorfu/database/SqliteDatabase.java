package com.bustravelcorfu.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.bustravelcorfu.entities.CancelTicketsDao;
import com.bustravelcorfu.entities.History_BookingDao;
import com.bustravelcorfu.entities.UsersDao;

public class SqliteDatabase extends SQLiteOpenHelper {
    //Database Name
    private static final String DATABASE_NAME = "bustravel.db";

    //Database Version
    private static final int DATABASE_VERSION = 1;
    //Tables
    private static final String TABLE_USERS = UsersDao.TABLENAME;
    private static final String TABLE_HISTORY_BOOKING = History_BookingDao.TABLENAME;
    private static final String TABLE_CANCEL_TICKET = CancelTicketsDao.TABLENAME;

    //Users Columns
    private static final String COLUMN_USER_ID = UsersDao.Properties.Id.columnName;
    private static final String COLUMN_USERNAME = UsersDao.Properties.Username.columnName;
    private static final String COLUMN_USER_PASSWORD = UsersDao.Properties.Password.columnName;
    private static final String COLUMN_PIN_USER = UsersDao.Properties.Pinuser.columnName;

    //History Booking Columns
    private static final String COLUMN_HISTORY_BOOK_ID = History_BookingDao.Properties.Id.columnName;
    private static final String COLUMN_DEPARTURE_POINT = History_BookingDao.Properties.Departure_point.columnName;
    private static final String COLUMN_DESTINATION = History_BookingDao.Properties.Destination.columnName;
    private static final String COLUMN_NUMBER_OF_TICKETS = History_BookingDao.Properties.Number_of_tickets.columnName;
    private static final String COLUMN_DATE = History_BookingDao.Properties.Date.columnName;
    private static final String COLUMN_TIME_TRAVEL = History_BookingDao.Properties.Time_travel.columnName;
    private static final String COLUMN_NUMBER_OF_SEAT = History_BookingDao.Properties.Number_of_seat.columnName;
    private static final String COLUMN_PRICE = History_BookingDao.Properties.Price.columnName;

    //Cancel Tickets Columns
    private static final String COLUMN_CANCEL_TICKET_ID = CancelTicketsDao.Properties.Id.columnName;
    private static final String COLUMN_CA_DEPARTURE_POINT = CancelTicketsDao.Properties.Capoint.columnName;
    private static final String COLUMN_CA_DESTINATION = CancelTicketsDao.Properties.Cadestination.columnName;
    private static final String COLUMN_CA_TICKETS = CancelTicketsDao.Properties.Catickets.columnName;
    private static final String COLUMN_CA_DATE = CancelTicketsDao.Properties.Cadate.columnName;
    private static final String COLUMN_CA_TIME_TRAVEL = CancelTicketsDao.Properties.Catimetravel.columnName;
    private static final String COLUMN_CA_NUMBER_SEAT = CancelTicketsDao.Properties.Canumberofseat.columnName;
    private static final String COLUMN_CA_PRICE = CancelTicketsDao.Properties.Caprice.columnName;

    private static SqliteDatabase instance;

    public SqliteDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "(" + COLUMN_USER_ID + " INTEGER PRIMARY KEY," + COLUMN_USERNAME + " TEXT," + COLUMN_USER_PASSWORD + " TEXT," + COLUMN_PIN_USER + " TEXT)";
        String CREATE_HISTORY_BOOKING_TABLE = "CREATE TABLE " + TABLE_HISTORY_BOOKING + "(" + COLUMN_HISTORY_BOOK_ID + " INTEGER PRIMARY KEY," + COLUMN_DEPARTURE_POINT + " TEXT," + COLUMN_DESTINATION + " TEXT," +
                COLUMN_NUMBER_OF_TICKETS + " TEXT," + COLUMN_DATE + " TEXT," + COLUMN_TIME_TRAVEL + " TEXT," + COLUMN_NUMBER_OF_SEAT + " TEXT," + COLUMN_PRICE +" TEXT)";
        String CREATE_CANCEL_TICKETS_TABLE = "CREATE TABLE " + TABLE_CANCEL_TICKET + "(" + COLUMN_CANCEL_TICKET_ID + " INTEGER PRIMARY KEY," +
                COLUMN_CA_DEPARTURE_POINT + " TEXT," + COLUMN_CA_DESTINATION + " TEXT," + COLUMN_CA_TICKETS + " TEXT," + COLUMN_CA_DATE + " TEXT," +
                COLUMN_CA_TIME_TRAVEL + " TEXT," + COLUMN_CA_NUMBER_SEAT + " TEXT," + COLUMN_CA_PRICE + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_HISTORY_BOOKING_TABLE);
        db.execSQL(CREATE_CANCEL_TICKETS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HISTORY_BOOKING);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CANCEL_TICKET);

    }
    public static SqliteDatabase get(Context ctx) {
        if (instance == null)
            instance = new SqliteDatabase(ctx);
        return instance;
    }
}
