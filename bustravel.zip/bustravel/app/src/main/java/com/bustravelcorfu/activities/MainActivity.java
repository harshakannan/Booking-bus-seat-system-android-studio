package com.bustravelcorfu.activities;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.bustravelcorfu.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private int mYear;
    private int mMonth;
    private int mDay;

    private TextView mDateDisplay;
    Button mPickDate;
    Spinner destination_spinner;
    Spinner point_spinner;
    Spinner tickets_spinner;
    Button but_overview;
    static final int DATE_DIALOG_ID = 0;
    private ProgressBar spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.setBackgroundColor(getResources().getColor(R.color.colorBorder));
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        point_spinner = (Spinner) findViewById(R.id.point_spiner);
        destination_spinner = (Spinner) findViewById(R.id.destination_spinner);
        tickets_spinner = (Spinner) findViewById(R.id.ticket_spinner);
        but_overview = (Button) findViewById(R.id.button_overview);
        mDateDisplay = (TextView) findViewById(R.id.showMyDate);
        mPickDate = (Button) findViewById(R.id.myDatePickerButton);
        spinner = (ProgressBar) findViewById(R.id.progressBar1);

        // Spinner departure point
        List<String> departure_point = new ArrayList<>();
        departure_point.add("Κέρκυρα");
        departure_point.add("Θεσσαλονίκη");
        departure_point.add("Πάτρα");
        departure_point.add("Λάρισα");
        departure_point.add("Αθήνα");
       /* departure_point.add("Βόλος");
        departure_point.add("Ιωάννινα");
        departure_point.add("Τρίκαλα");
        departure_point.add("Σέρρες");
        departure_point.add("Αλεξανδρούπολη");
        departure_point.add("Ξάνθη");
        departure_point.add("Κομοτινή");
        departure_point.add("Καβάλα");
        departure_point.add("Λαμία");*/

        //Spinner destination
        final List<String> destination = new ArrayList<>();
        destination.add("Αθήνα");
        destination.add("Θεσσαλονίκη");
        destination.add("Πάτρα");
        destination.add("Λάρισα");
        destination.add("Κέρκυρα");
        /*destination.add("Βόλος");
        destination.add("Ιωάννινα");
        destination.add("Τρίκαλα");
        destination.add("Σέρρες");
        destination.add("Αλεξανδρούπολη");
        destination.add("Ξάνθη");
        destination.add("Κομοτινή");
        destination.add("Καβάλα");
        destination.add("Λαμία");*/

        //Spinner tickets number
        List<String> ticket = new ArrayList<>();
        ticket.add("1");
        ticket.add("2");
        ticket.add("3");
        ticket.add("4");
        ticket.add("5");
        ticket.add("6");
        ticket.add("7");
        ticket.add("8");
        ticket.add("9");
        ticket.add("10");

        // Creating adapter for spinner
        ArrayAdapter<String> pointAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, departure_point);
        ArrayAdapter<String> destinationAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, destination);
        ArrayAdapter<String> ticketAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, ticket);

        // attaching data adapter to spinner
        point_spinner.setAdapter(pointAdapter);
        destination_spinner.setAdapter(destinationAdapter);
        tickets_spinner.setAdapter(ticketAdapter);


        but_overview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Validation();
            }
        });

        point_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        mPickDate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showDialog(DATE_DIALOG_ID);
            }
        });

        // get the current date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        // display the current date
        updateDisplay();

        FloatingActionButton button = findViewById(R.id.fab);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Email = new Intent(Intent.ACTION_SEND);
                Email.setType("text/email");
                Email.putExtra(Intent.EXTRA_EMAIL, new String[]{"your_email@gmail.com"});/*replace with your email*/
                Email.putExtra(Intent.EXTRA_SUBJECT, "Feedback from " + Build.MODEL + " user");
                Email.putExtra(Intent.EXTRA_TEXT, "Dear Bus Travel team," + "");
                startActivity(Intent.createChooser(Email, "Send Feedback:"));
            }
        });
    }

    private void Validation() {
        String _point = String.valueOf(point_spinner.getSelectedItem());
        String _destination = String.valueOf(destination_spinner.getSelectedItem());

        if (_point.equals("Κέρκυρα") && _destination.equals("Κέρκυρα")) {
            dialogWarning();
        } else if (_point.equals("Θεσσαλονίκη") && _destination.equals("Θεσσαλονίκη") || _point.equals("Θεσσαλονίκη") && _destination.equals("Αθήνα")
                || _point.equals("Θεσσαλονίκη") && _destination.equals("Πάτρα") || _point.equals("Θεσσαλονίκη") && _destination.equals("Λάρισα")) {
            dialogWarning();
        } else if (_point.equals("Πάτρα") && _destination.equals("Πάτρα") || _point.equals("Πάτρα") && _destination.equals("Αθήνα")
                || _point.equals("Πάτρα") && _destination.equals("Θεσσαλονίκη") || _point.equals("Πάτρα") && _destination.equals("Λάρισα")) {
            dialogWarning();
        } else if (_point.equals("Λάρισα") && _destination.equals("Λάρισα") || _point.equals("Λάρισα") && _destination.equals("Αθήνα")
                || _point.equals("Λάρισα") && _destination.equals("Πάτρα") || _point.equals("Λάρισα") && _destination.equals("Θεσσαλονίκη")) {
            dialogWarning();
        } else if (_point.equals("Αθήνα") && _destination.equals("Αθήνα") || _point.equals("Αθήνα") && _destination.equals("Θεσσαλονίκη")
                || _point.equals("Αθήνα") && _destination.equals("Πάτρα") || _point.equals("Αθήνα") && _destination.equals("Λάρισα")) {
            dialogWarning();
        } else {
            spinner.setVisibility(View.GONE);
            spinner.setVisibility(View.VISIBLE);
            Intent intent = new Intent(MainActivity.this, SelectBusActivity.class);
            intent.putExtra("point", String.valueOf(point_spinner.getSelectedItem()));
            intent.putExtra("destination", String.valueOf(destination_spinner.getSelectedItem()));
            intent.putExtra("tickets", String.valueOf(tickets_spinner.getSelectedItem()));
            intent.putExtra("day", String.valueOf(mDay));
            intent.putExtra("month", String.valueOf(mMonth +1));
            intent.putExtra("year", String.valueOf(mYear));
            startActivity(intent);
        }
    }

    private void updateDisplay() {
        this.mDateDisplay.setText(
                new StringBuilder()
                        // Month is 0 based so add 1
                        .append(mDay).append("-")
                        .append(mMonth + 1).append("-")
                        .append(mYear).append(" "));
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DATE_DIALOG_ID:
                return new DatePickerDialog(this,
                        mDateSetListener,
                        mYear, mMonth, mDay);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener mDateSetListener =
            new DatePickerDialog.OnDateSetListener() {
                public void onDateSet(DatePicker view, int year,
                                      int monthOfYear, int dayOfMonth) {
                    mYear = year;
                    mMonth = monthOfYear;
                    mDay = dayOfMonth;
                    updateDisplay();
                }
            };

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
            Intent exit = new Intent(Intent.ACTION_MAIN);
            exit.addCategory(Intent.CATEGORY_HOME);
            exit.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(exit);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        /*if (id == R.id.action_settings) {
            return true;
        }*/
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_search_travel) {
            Intent main_activity = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(main_activity);

        } else if (id == R.id.nav_cancel_ticket) {
            Intent intent = new Intent(getApplicationContext(), CancelTicketActivity.class);
            startActivity(intent);

        } else if (id == R.id.nav_history_travel) {
            Intent intent = new Intent(getApplicationContext(), HistoryBookingActivity.class);
            startActivity(intent);

        } else if (id == R.id.nav_conditions) {
            Intent intent = new Intent(getApplicationContext(), ContitionsActivity.class);
            startActivity(intent);

        } else if (id == R.id.nav_share) {
            Intent sharingIntent = new Intent(Intent.ACTION_SEND);
            sharingIntent.setAction(Intent.ACTION_SEND);
            sharingIntent.putExtra(Intent.EXTRA_TEXT, "Αγόρασε το εισιτήριο σου και ταξίδεψε από την Κέρκυρα στις πόλεις της Ελλάδος μέσω της εφαρμογής Bus Travel Corfu \n\n https://play.google.com/store");/*replace url from app in play store*/
            sharingIntent.setType("text/plain");
            startActivity(Intent.createChooser(sharingIntent, "Share via"));
        } else if (id == R.id.nav_rate) {
            Intent intent = new Intent(Intent.ACTION_VIEW)
                    .setData(Uri
                            .parse("https://play.google.com/store"));/*replace url from app in play store */
            startActivity(intent);
        } else if (id == R.id.nav_contact) {
            Intent Email = new Intent(Intent.ACTION_SEND);
            Email.setType("text/email");
            Email.putExtra(Intent.EXTRA_EMAIL, new String[]{"your_email@gmail.com"});/*replace with your email*/
            Email.putExtra(Intent.EXTRA_SUBJECT, "Feedback from " + Build.MODEL + " user");
            Email.putExtra(Intent.EXTRA_TEXT, "Dear Bus Travel team," + "");
            startActivity(Intent.createChooser(Email, "Send Feedback:"));
        } else if (id == R.id.nav_about) {
            Intent intent = new Intent(getApplicationContext(), AboutActivity.class);
            startActivity(intent);

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void dialogWarning() {
        AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
        alertDialog.setTitle("Ειδοποίηση");
        alertDialog.setMessage("Αναζητήστε εισητήρια με σημείο αναχώρησης την Κέρκυρα προς τις πόλεις της Ελλάδας, ή από τις πόλεις της Ελλάδας προς την Κέρκυρα.");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }
}
