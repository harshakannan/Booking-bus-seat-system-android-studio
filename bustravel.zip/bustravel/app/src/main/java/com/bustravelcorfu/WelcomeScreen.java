package com.bustravelcorfu;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.bustravelcorfu.views.welcome.ParallaxPage;
import com.bustravelcorfu.views.welcome.WelcomeActivity;
import com.bustravelcorfu.views.welcome.WelcomeConfiguration;


public class WelcomeScreen extends WelcomeActivity implements View.OnClickListener {

    public static final String WELCOME_SCREEN_ACTIVE = "welcome_screen_active";
    public static final int REQUEST_WELCOME_RESULT_START = 1;

    @Override
    protected WelcomeConfiguration configuration() {

        return new WelcomeConfiguration.Builder(this)
                .canSkip(false)
                .backButtonNavigatesPages(false)
                .bottomLayout(WelcomeConfiguration.BottomLayout.BUTTON_BAR_SINGLE)
                .page(new ParallaxPage(R.layout.welcome_screen_1, getResources().getString(R.string.welcome_title_1), getResources().getString(R.string.welcome_desc_1)).background(R.color.colorAccent))
                .page(new ParallaxPage(R.layout.welcome_screen_2, getResources().getString(R.string.welcome_title_2), getResources().getString(R.string.welcome_desc_2)).background(R.color.colorPrimary))
                .build();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Button dologin = (Button) findViewById(R.id.wel_button_bar_first);
        if (dologin != null) {
            dologin.setText(getResources().getString(R.string.welcome_button_1));
            dologin.setOnClickListener(this);
            dologin.setTag(REQUEST_WELCOME_RESULT_START);
            dologin.setTypeface(Typeface.create(dologin.getTypeface(), Typeface.BOLD));
        }

       /* Button dodemo = (Button) findViewById(R.id.wel_button_bar_second);
        if (dodemo != null) {
            dodemo.setText(getResources().getString(R.string.welcome_button_2));
            dodemo.setOnClickListener(this);
            dodemo.setTag(REQUEST_WELCOME_RESULT_DEMO);
            dodemo.setTypeface(Typeface.create(dodemo.getTypeface(), Typeface.BOLD));
        }*/
    }

    @Override
    public void onClick(View v) {
        setResult((Integer) v.getTag());
        finish();
    }

}
