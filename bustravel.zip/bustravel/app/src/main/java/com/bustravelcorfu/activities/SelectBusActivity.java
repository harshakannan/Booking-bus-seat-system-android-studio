package com.bustravelcorfu.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.bustravelcorfu.R;

import java.util.ArrayList;
import java.util.List;

public class SelectBusActivity extends AppCompatActivity {
    Spinner mSelect_bus_spinner;
    Button mSelect_Seats;
    Toolbar mActionBarToolbar;
    TextView mPoint_preview, mDestination_preview, mTickets_preview, mDate_preview;
    String point, destination, tickets, day, month, year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_select_bus);

        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.layout_select_bus);
        linearLayout.setBackgroundColor(getResources().getColor(R.color.colorBorder));
        mActionBarToolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mActionBarToolbar);
        mActionBarToolbar.setNavigationIcon(R.drawable.ic_arrow_back_24dp);
        setTitle("Επιλογή Λεωφορείου");

        mSelect_bus_spinner = (Spinner) findViewById(R.id.select_bus_spiner);
        mSelect_Seats = (Button) findViewById(R.id.button_select_seats);
        mPoint_preview = (TextView) findViewById(R.id.point_preview);
        mDestination_preview = (TextView) findViewById(R.id.destination_preview);
        mTickets_preview = (TextView) findViewById(R.id.tickets_preview);
        mDate_preview = (TextView) findViewById(R.id.date_preview);

        point = getIntent().getStringExtra("point");
        destination = getIntent().getStringExtra("destination");
        tickets = getIntent().getStringExtra("tickets");
        day = getIntent().getStringExtra("day");
        month = getIntent().getStringExtra("month");
        year = getIntent().getStringExtra("year");

        mPoint_preview.setText(point);
        mDestination_preview.setText(destination);
        mTickets_preview.setText(tickets);
        mDate_preview.setText(new StringBuilder()
                .append(day).append("-")
                .append(month).append("-")
                .append(year).append(" "));

        List<String> select_bus_list = new ArrayList<>();
        select_bus_list.add("8:15π.μ. εταιρεία Υπεραστικό Κτελ");
        select_bus_list.add("13:30μ.μ. εταιρεία Υπεραστικό Κτελ");
        select_bus_list.add("20:15μ.μ. εταιρεία Υπεραστικό Κτελ");

        ArrayAdapter<String> busAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, select_bus_list);
        mSelect_bus_spinner.setAdapter(busAdapter);

        mSelect_bus_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        mSelect_Seats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent select_seat_activity = new Intent(getApplicationContext(), SeatSelectionActivity.class);
                select_seat_activity.putExtra("point",point);
                select_seat_activity.putExtra("destination",destination);
                select_seat_activity.putExtra("tickets", tickets);
                select_seat_activity.putExtra("day", day);
                select_seat_activity.putExtra("month", month);
                select_seat_activity.putExtra("year", year);
                select_seat_activity.putExtra("time", String.valueOf(mSelect_bus_spinner.getSelectedItem()));
                startActivity(select_seat_activity);
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent main_activity = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(main_activity);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {

        switch (menuItem.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
        }

        return super.onOptionsItemSelected(menuItem);
    }
}
