package com.bustravelcorfu.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.bustravelcorfu.BusTravelProvider;
import com.bustravelcorfu.R;
import com.bustravelcorfu.activities.HistoryBookingActivity;
import com.bustravelcorfu.activities.PreviewHistoryActivity;
import com.bustravelcorfu.entities.History_Booking;
import com.bustravelcorfu.holders.HistoryHolder;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryHolder> {
    private List<History_Booking> mListHistoryBooking;
    private Context mContext;
    private HistoryBookingActivity mActivity;

    public HistoryAdapter(Context context, List<History_Booking> bookingList, HistoryBookingActivity activity) {
        this.mContext = context;
        this.mListHistoryBooking = bookingList;
        this.mActivity = activity;
    }

    @NonNull
    @Override
    public HistoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.history_list_items, parent, false);
        return new HistoryHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final HistoryHolder holder, int position) {
        final History_Booking historyBooking = mListHistoryBooking.get(position);

        holder.mPoint_history.setText(new StringBuilder()
                .append(historyBooking.getDeparture_point())
                .append(" - "));
        holder.mDestination_history.setText(historyBooking.getDestination());
        holder.mDate_history.setText(historyBooking.getDate());
        holder.mPrice_history.setText(historyBooking.getPrice());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, PreviewHistoryActivity.class);
                intent.putExtra("point", historyBooking.getDeparture_point());
                intent.putExtra("destination", historyBooking.getDestination());
                intent.putExtra("tickets", historyBooking.getNumber_of_tickets());
                intent.putExtra("date", historyBooking.getDate());
                intent.putExtra("time", historyBooking.getTime_travel());
                intent.putExtra("seats", historyBooking.getNumber_of_seat());
                intent.putExtra("price", historyBooking.getPrice());
                mContext.startActivity(intent);
            }
        });

        holder.mRemove_history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogOneItemDelete(holder, holder.getAdapterPosition());
            }
        });

    }

    private void dialogOneItemDelete(final HistoryHolder holder, final int position) {
        final History_Booking historyBooking = mListHistoryBooking.get(position);
        final long id = historyBooking.getId();
        LayoutInflater layoutInflater = LayoutInflater.from(mActivity);
        View dialogView = layoutInflater.inflate(R.layout.dialog_confirm_delete, null);
        final AlertDialog dialog = new AlertDialog.Builder(mActivity).create();
        Button btnNo = dialogView.findViewById(R.id.btn_no);
        Button btnYes = dialogView.findViewById(R.id.btn_yes);

        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.getContentResolver().delete(BusTravelProvider.CONTENT_HISTORY_BOOK_DELETE, String.valueOf(id), null);
                mListHistoryBooking.remove(holder.getAdapterPosition());
                notifyItemRemoved(holder.getAdapterPosition());

                Toast.makeText(mContext, "Επιτυχής διαγραφή!", Toast.LENGTH_LONG).show();
                new android.os.Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        dialog.dismiss();
                    }
                });
            }
        });

        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.setView(dialogView);
        dialog.show();
    }

    @Override
    public int getItemCount() {
        return mListHistoryBooking.size();
    }
}
