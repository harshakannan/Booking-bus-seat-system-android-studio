package com.bustravelcorfu.activities;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bustravelcorfu.R;
import com.bustravelcorfu.BusTravelProvider;
import com.bustravelcorfu.entities.Users;

import java.util.ArrayList;
import java.util.List;

public class ForgotPasswordActivity extends AppCompatActivity {
    TextView mTextEmail;
    Button mButtonConfirm;
    List<Users> mUsersList;
    private String mEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_forgot_password);

        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.forgotPasswordLayout);
        linearLayout.setBackgroundColor(getResources().getColor(R.color.colorBorder));
        TextInputLayout confirmEmail = (TextInputLayout) findViewById(R.id.textInputLayoutEmail);
        mTextEmail = (TextInputEditText) findViewById(R.id.textEmailConfirm);
        mButtonConfirm = (Button) findViewById(R.id.emailButtonConfirm);

        //Toolbar Title
        setTitle("Ανάκτηση Κωδικού");

        mUsersList = new ArrayList<>();

        String URL = "content://com.bustravelcorfu.provider/" + BusTravelProvider.USERS_PATH + "";
        final Uri _users = Uri.parse(URL);
        final Cursor cursor = getContentResolver().query(_users, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                Users users = new Users();
                users.setId(cursor.getLong(0));
                users.setUsername(cursor.getString(1));
                users.setPassword(cursor.getString(2));
                users.setPinuser(cursor.getString(3));
                mUsersList.add(users);
            }
        }

        for (int i = 0; i < mUsersList.size(); i++) {
            mEmail = mUsersList.get(i).getUsername();
        }


        mButtonConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                VerifyEmailConfirm();
            }
        });
    }

    private void VerifyEmailConfirm(){
        final String cEmail = mTextEmail.getText().toString();

        if(cEmail.equals(mEmail)){
            Intent reset_activity = new Intent(this, ResetPasswordActivity.class);
            startActivity(reset_activity);
        }else {
            Toast.makeText(getApplicationContext(), "Wrong email try again", Toast.LENGTH_LONG).show();
        }
    }
}