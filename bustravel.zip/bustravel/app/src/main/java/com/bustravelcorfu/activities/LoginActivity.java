package com.bustravelcorfu.activities;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bustravelcorfu.R;
import com.bustravelcorfu.BusTravelProvider;
import com.bustravelcorfu.WelcomeScreen;
import com.bustravelcorfu.entities.Users;
import com.bustravelcorfu.views.welcome.WelcomeHelper;

import java.util.ArrayList;
import java.util.List;


public class LoginActivity extends BaseActivity {
    TextView mPassword;
    TextView mConfirmPass;
    TextView mEmailUser;
    List<Users> mUsersList;
    Button mLoginPin;
    Button mRegisterPin;
    AppCompatTextView mForgotPas;
    Toolbar mActionBarToolbar;
    private String pas;
    private ProgressBar spinner;
    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;
    WelcomeHelper mWelcomeScreen;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // get shared preferences
        prefs = getSharedPreferences("MasterPrefs", MODE_PRIVATE);
        editor = prefs.edit();
    }

    public void loginPinUser() {
        final String cPassword = mPassword.getText().toString();

        if (cPassword.equals(pas)) {
            spinner.setVisibility(View.GONE);
            spinner.setVisibility(View.VISIBLE);
            Intent detailsScreen = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(detailsScreen);
        } else {
            Toast.makeText(getApplicationContext(), "Wrong password try again", Toast.LENGTH_LONG).show();
        }
    }

    public void registerPinUser() {
        String cPassword = mPassword.getText().toString();
        String cConfirmPass = mConfirmPass.getText().toString();
        String cEmail = mEmailUser.getText().toString();

        ContentValues values = new ContentValues();
        if (cPassword.isEmpty() && cConfirmPass.isEmpty() && cEmail.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Wrong password. Password is empty", Toast.LENGTH_LONG).show();
        } else if (cPassword.length() < 4) {
            Toast.makeText(getApplicationContext(), "Password must be at least 4 digits", Toast.LENGTH_LONG).show();
        } else if (!cPassword.equals(cConfirmPass)) {
            Toast.makeText(getApplicationContext(), "Password is different with confirm Password", Toast.LENGTH_LONG).show();
        } else {
            values.put(BusTravelProvider.COLUMN_USER_PASSWORD, cPassword);
            values.put(BusTravelProvider.COLUMN_USERNAME, cEmail);
            getContentResolver().insert(BusTravelProvider.CONTENT_USERS_URI_INSERT, values);
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        }
    }

    public void initializeMainActivity() {
        setContentView(R.layout.layout_register_pin);

        RelativeLayout linearLayout = (RelativeLayout) findViewById(R.id.register_pin);
        linearLayout.setBackgroundColor(getResources().getColor(R.color.colorBorder));
        mActionBarToolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mActionBarToolbar);

        TextInputLayout confrimPassword = (TextInputLayout) findViewById(R.id.register_password_wrapper);
        TextInputLayout email_register = (TextInputLayout) findViewById(R.id.register_email_wrapper);
        TextView algorithmText = (TextView) findViewById(R.id.register_main);
        TextView createPassword = (TextView) findViewById(R.id.create_password);
        TextView securePassword = (TextView) findViewById(R.id.secure_password);


        mUsersList = new ArrayList<>();

        mPassword = (TextView) findViewById(R.id.password_register);
        mConfirmPass = (TextView) findViewById(R.id.password_confirm);
        mEmailUser = (TextView) findViewById(R.id.email_register);
        mLoginPin = (Button) findViewById(R.id.login_pin);
        mRegisterPin = (Button) findViewById(R.id.register);
        spinner = (ProgressBar) findViewById(R.id.progressBar1);
        mForgotPas = (AppCompatTextView) findViewById(R.id.forgotPassword);

        String URL = "content://com.bustravelcorfu.provider/" + BusTravelProvider.USERS_PATH + "";
        final Uri _users = Uri.parse(URL);
        final Cursor cursor = getContentResolver().query(_users, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                Users users = new Users();
                users.setId(cursor.getLong(0));
                users.setUsername(cursor.getString(1));
                users.setPassword(cursor.getString(2));
                users.setPinuser(cursor.getString(3));
                mUsersList.add(users);
            }
        }

        for (int i = 0; i < mUsersList.size(); i++) {
            pas = mUsersList.get(i).getPassword();
        }

        if (mUsersList.size() > 0) {
            confrimPassword.setVisibility(View.INVISIBLE);
            algorithmText.setVisibility(View.INVISIBLE);
            mRegisterPin.setVisibility(View.INVISIBLE);
            createPassword.setVisibility(View.INVISIBLE);
            mEmailUser.setVisibility(View.INVISIBLE);
            email_register.setVisibility(View.INVISIBLE);
            mLoginPin.setVisibility(View.VISIBLE);
            securePassword.setVisibility(View.VISIBLE);
            mForgotPas.setVisibility(View.VISIBLE);

        } else {
            confrimPassword.setVisibility(View.VISIBLE);
            algorithmText.setVisibility(View.VISIBLE);
            mRegisterPin.setVisibility(View.VISIBLE);
            createPassword.setVisibility(View.VISIBLE);
            mEmailUser.setVisibility(View.VISIBLE);
            email_register.setVisibility(View.VISIBLE);
            mLoginPin.setVisibility(View.INVISIBLE);
            securePassword.setVisibility(View.INVISIBLE);
            mForgotPas.setVisibility(View.INVISIBLE);
        }

        mLoginPin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginPinUser();
            }
        });

        mRegisterPin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerPinUser();
            }
        });

        mForgotPas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent forgotPasActivity = new Intent(getApplicationContext(), ForgotPasswordActivity.class);
                startActivity(forgotPasActivity);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        // first run preference
        if (prefs.getBoolean("firstrun", true)) { // get firstrun preference
            mWelcomeScreen = new WelcomeHelper(this, WelcomeScreen.class);
            mWelcomeScreen.forceShow(); // force show welcome screen
            editor.putBoolean("firstrun", false).apply(); // put firstrun preference
        } else {
            initializeMainActivity(); // initialize main activity
        }
    }
}
