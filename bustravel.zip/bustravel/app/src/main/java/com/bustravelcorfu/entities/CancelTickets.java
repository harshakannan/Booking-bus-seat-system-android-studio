package com.bustravelcorfu.entities;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;

@Entity
public class CancelTickets {
    @Id

    private Long id;
    private String capoint;
    private String cadestination;
    private String catickets;
    private String cadate;
    private String catimetravel;
    private String canumberofseat;
    private String caprice;
    @Generated(hash = 959514852)
    public CancelTickets(Long id, String capoint, String cadestination,
            String catickets, String cadate, String catimetravel,
            String canumberofseat, String caprice) {
        this.id = id;
        this.capoint = capoint;
        this.cadestination = cadestination;
        this.catickets = catickets;
        this.cadate = cadate;
        this.catimetravel = catimetravel;
        this.canumberofseat = canumberofseat;
        this.caprice = caprice;
    }
    @Generated(hash = 1964567498)
    public CancelTickets() {
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getCapoint() {
        return this.capoint;
    }
    public void setCapoint(String capoint) {
        this.capoint = capoint;
    }
    public String getCadestination() {
        return this.cadestination;
    }
    public void setCadestination(String cadestination) {
        this.cadestination = cadestination;
    }
    public String getCatickets() {
        return this.catickets;
    }
    public void setCatickets(String catickets) {
        this.catickets = catickets;
    }
    public String getCadate() {
        return this.cadate;
    }
    public void setCadate(String cadate) {
        this.cadate = cadate;
    }
    public String getCatimetravel() {
        return this.catimetravel;
    }
    public void setCatimetravel(String catimetravel) {
        this.catimetravel = catimetravel;
    }
    public String getCanumberofseat() {
        return this.canumberofseat;
    }
    public void setCanumberofseat(String canumberofseat) {
        this.canumberofseat = canumberofseat;
    }
    public String getCaprice() {
        return this.caprice;
    }
    public void setCaprice(String caprice) {
        this.caprice = caprice;
    }
}
