package com.bustravelcorfu.activities;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bustravelcorfu.R;
import com.bustravelcorfu.BusTravelProvider;
import com.bustravelcorfu.entities.Users;

import java.util.ArrayList;
import java.util.List;

public class ResetPasswordActivity extends AppCompatActivity {
    List<Users> mUsersList;
    private String pas;
    TextView mPasswordReset;
    TextView mConfirmPassReset;
    Button mButtonReset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_reset_password);

        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.resetPasswordLayout);
        linearLayout.setBackgroundColor(getResources().getColor(R.color.colorBorder));

        //Toolbar Title
        setTitle("Επαναφορά Κωδικού");

        TextInputLayout confrimPassword = (TextInputLayout) findViewById(R.id.reset_pas_wrapper);
        TextInputLayout confrimPass = (TextInputLayout) findViewById(R.id.reset_password_wrapper);

        mPasswordReset = (TextView) findViewById(R.id.password_reset);
        mConfirmPassReset = (TextView) findViewById(R.id.password_reset_confirm);
        mButtonReset = (Button) findViewById(R.id.buttonReset);

        mUsersList = new ArrayList<>();

        String URL = "content://com.bustravelcorfu.provider/" + BusTravelProvider.USERS_PATH + "";
        final Uri _users = Uri.parse(URL);
        final Cursor cursor = getContentResolver().query(_users, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                Users users = new Users();
                users.setId(cursor.getLong(0));
                users.setUsername(cursor.getString(1));
                users.setPassword(cursor.getString(2));
                users.setPinuser(cursor.getString(3));
                mUsersList.add(users);
            }
        }
        mButtonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerPinUser();
            }
        });

    }

    public void registerPinUser() {
        String cPasswordReset = mPasswordReset.getText().toString();
        String cConfirmPassReset = mConfirmPassReset.getText().toString();

        ContentValues values = new ContentValues();
        if (cPasswordReset.isEmpty() && cConfirmPassReset.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Wrong password. Password is empty", Toast.LENGTH_LONG).show();
        } else if (cPasswordReset.length() < 4) {
            Toast.makeText(getApplicationContext(), "Password must be at least 4 digits", Toast.LENGTH_LONG).show();
        } else if (!cPasswordReset.equals(cConfirmPassReset)) {
            Toast.makeText(getApplicationContext(), "Password is different with confirm Password", Toast.LENGTH_LONG).show();
        } else {
            values.put(BusTravelProvider.COLUMN_USER_PASSWORD, cPasswordReset);
            getContentResolver().update(BusTravelProvider.CONTENT_USERS_URI_UPDATE, values, cPasswordReset, null);
            Toast.makeText(getApplicationContext(), "Password update have been successful", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        }
    }
}
