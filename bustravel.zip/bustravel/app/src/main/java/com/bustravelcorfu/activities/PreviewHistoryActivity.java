package com.bustravelcorfu.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

import com.bustravelcorfu.R;

public class PreviewHistoryActivity extends AppCompatActivity {
    Toolbar mActionBarToolbar;
    TextView mPoint_preview, mDestination_preview, mTickets_preview, mDate_preview, mSeatPreview, mTimePreview, mPricePreview;
    String point, destination, tickets, date, time, seats, price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview_history);
        mActionBarToolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mActionBarToolbar);
        mActionBarToolbar.setNavigationIcon(R.drawable.ic_arrow_back_24dp);
        setTitle("Ιστορικό Κρατήσεων");

        mPoint_preview = (TextView) findViewById(R.id.point_preview);
        mDestination_preview = (TextView) findViewById(R.id.destination_preview);
        mTickets_preview = (TextView) findViewById(R.id.tickets_preview);
        mDate_preview = (TextView) findViewById(R.id.date_preview);
        mSeatPreview = (TextView) findViewById(R.id.seat_preview);
        mTimePreview = (TextView) findViewById(R.id.time_preview);
        mPricePreview = (TextView) findViewById(R.id.price_preview);

        point = getIntent().getStringExtra("point");
        destination = getIntent().getStringExtra("destination");
        tickets = getIntent().getStringExtra("tickets");
        date = getIntent().getStringExtra("date");
        time = getIntent().getStringExtra("time");
        seats = getIntent().getStringExtra("seats");
        price = getIntent().getStringExtra("price");

        mPoint_preview.setText(point);
        mDestination_preview.setText(destination);
        mTickets_preview.setText(tickets);
        mDate_preview.setText(date);
        mTimePreview.setText(time);
        mSeatPreview.setText(seats);
        mPricePreview.setText(price);

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                Intent mainActivity = new Intent(this, HistoryBookingActivity.class);
                startActivity(mainActivity);
                break;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
